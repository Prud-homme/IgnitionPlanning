def rename_site(database, old_site, new_site):
	"""Renomme le site par un nouveau nom (plannings, plannings_exception, equipements)"""
	query = """UPDATE equipements 
	SET 
		site='%s'
	WHERE site='%s'
	""" % (
		new_site,
		old_site,
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings 
	SET 
		site='%s'
	WHERE site='%s'
	""" % (
		new_site,
		old_site,
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings_exception 
	SET 
		site='%s'
	WHERE site='%s'
	""" % (
		new_site,
		old_site,
	)
	system.db.runUpdateQuery(query,database)
	
def rename_site_devices(database, old_site, new_site):
	"""Renomme le site par un nouveau nom (devices)"""
	query = """UPDATE devices 
	SET 
		site='%s'
	WHERE site='%s'
	""" % (
		new_site,
		old_site,
	)
	system.db.runUpdateQuery(query,database)
	

def rename_gp(database, site, old_groupe, new_groupe):
	"""Renomme le groupe d'un site par un nouveau nom (plannings, plannings_exception, equipements)"""
	query = """UPDATE equipements 
	SET 
		groupe='%s'
	WHERE site='%s'
	and groupe='%s'
	""" % (
		new_groupe,
		site,
		old_groupe,
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings 
	SET 
		groupe='%s'
	WHERE site='%s'
	and groupe='%s'
	""" % (
		new_groupe,
		site,
		old_groupe,
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings_exception 
	SET 
		groupe='%s'
	WHERE site='%s'
	and groupe='%s'
	""" % (
		new_groupe,
		site,
		old_groupe,
	)
	system.db.runUpdateQuery(query,database)


def rename_equip(database, site, groupe, old_equip, new_equip):
	"""Renomme l'equipement d'un site et groupe par un nouveau nom (plannings, plannings_exception, equipements)"""
	query = """UPDATE equipements 
	SET 
		equipement='%s'
	WHERE site='%s'
	and groupe='%s'
	and equipement='%s'
	""" % (
		new_equip,
		site,
		groupe,
		old_equip,
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings 
	SET 
		equipement='%s'
	WHERE site='%s'
	and groupe='%s'
	and equipement='%s'
	""" % (
		new_equip,
		site,
		groupe,
		old_equip,
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings_exception 
	SET 
		equipement='%s'
	WHERE site='%s'
	and groupe='%s'
	and equipement='%s'
	""" % (
		new_equip,
		site,
		groupe,
		old_equip,
	)
	system.db.runUpdateQuery(query,database)
	

def rename(database, dataset1, dataset2, field):
	"""Met a jour les tables equipements et plannings en fonction des donnees fournies"""
	for i in range(dataset1.getRowCount()):
		old_value = dataset1.getValueAt(i, field)
		new_value = dataset2.getValueAt(i, 0)
		if old_value == new_value:
			continue
		
		if field == "site":
			rename_site(database, old_value, new_value)
		
		elif field == "groupe":
			site = dataset1.getValueAt(i, "site")
			rename_gp(database, site, old_value, new_value)
			
		elif field == "equipement":
			site = dataset1.getValueAt(i, "site")
			groupe = dataset1.getValueAt(i, "groupe")
			rename_equip(database, site, groupe, old_value, new_value)
		
