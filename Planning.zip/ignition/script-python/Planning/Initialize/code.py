import system

def create_tables(database):
	queries = [
		"""
		CREATE TABLE equipements
		(
		  site TEXT,
		  groupe TEXT,
		  equipement TEXT
		)
		""",	
		"""
		CREATE TABLE plannings
		(
		  h_start TEXT,
		  m_start TEXT,
		  h_stop TEXT,
		  m_stop TEXT,
		  plage INT,
		  jour INT,
		  site TEXT,
		  groupe TEXT,
		  equipement TEXT
		)
		""",
		"""
		CREATE TABLE plannings_exception
		(
		  h_start TEXT,
		  m_start TEXT,
		  h_stop TEXT,
		  m_stop TEXT,
		  date_deb TEXT,
		  date_fin TEXT,
		  plage INT,
		  site TEXT,
		  groupe TEXT,
		  equipement TEXT,
		  commentaire TEXT
		)
		""",
	]
	
	results = [system.db.runQuery(query, database) for query in queries]
	
def add_support_for_modbus(database):
	queries = [
		"""
		CREATE TABLE devices
		(
		  device TEXT NOT NULL,
		  site TEXT NOT NULL
		)
		""",	
		"""
		ALTER TABLE equipements
		ADD COLUMN num_mb INT
		""",
	]
	
	results = [system.db.runQuery(query, database) for query in queries]
	
def add_support_for_devio(database):
	queries = [
		"""
		ALTER TABLE equipements
		ADD COLUMN id_devio INT,
		ADD COLUMN nom_devio TEXT
		""",
	]
	
	results = [system.db.runQuery(query, database) for query in queries]
