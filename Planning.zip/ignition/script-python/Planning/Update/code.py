import system

def query_select_equipements(site, groupe, equipement):
	"""Verifier la présence de l'equipement dans la table equipements"""
	query = """
	Select * from equipements
	where site= '%s' 
	and groupe='%s' 
	and equipement = '%s'
	""" % (
		site,
		groupe,
		equipement,
	)
	return query
	
	
def query_insert_equipements(site, groupe, equipement):
	"""Ajout de l'equipement dans la table equipements"""
	query = """
	Insert into equipements (site, groupe, equipement)
	Values ('%s', '%s', '%s')
	""" % (
		site,
		groupe,
		equipement,
	)
	return query

	
def update_equipements(database, site, groupe, equipement):
	"""Ajout de l'equipement a la bdd s'il n'est pas deja present"""
	query = query_select_equipements(site, groupe, equipement)		
	result = system.db.runQuery(query,database)
	if len(result)==0:
		query = query_insert_equipements(site, groupe, equipement)
		system.db.runUpdateQuery(query,database)
		

def query_select_plannings(site, groupe, equipement, plage, jour):
	"""Verifier la presence de l'equipement pour ce jour et cette plage dans la table plannings"""
	query = """
	Select * from plannings
	where h_start = '%s'
	and m_start = '%s'
	and h_stop = '%s'
	and m_stop='%s'
	and plage=%d
	and jour=%d
	and site= '%s'
	and groupe='%s'
	and equipement = '%s' 
	""" % (
		"00", 
		"00", 
		"00", 
		"00", 
		plage, 
		jour, 
		site, 
		groupe, 
		equipement,
	)
	return query
		
		
def query_insert_plannings(site, groupe, equipement, plage, jour):
	"""Ajout du jour et plage pour l'equipement dans la table plannings"""
	query = """
	Insert into plannings
	(h_start, m_start, h_stop, m_stop, plage, jour, site, groupe, equipement)
	Values ('%s','%s','%s','%s', %d, %d,'%s','%s','%s')
	""" % (
		"00",
		"00",
		"00",
		"00",
		plage,
		jour,
		site,
		groupe,
		equipement,
	)
	return query


def update_plannings(database, site, groupe, equipement):
	"""Pre-remplissage de la table plannings pour la période hebdo, verifie la presence avant ajout"""
	list_jours = [1,2,3,4,5,6,7]
	list_plages = [1,2]	
	for jour in list_jours:
		for plage in list_plages:
			query = query_select_plannings(site, groupe, equipement, plage, jour)
			result = system.db.runQuery(query,database)
			if len(result)==0:
				query = query_insert_plannings(site, groupe, equipement, plage, jour)
				system.db.runUpdateQuery(query,database)
	

def add_num_mb(database, site, groupe, equipement, num_mb):
	"""Ajout du numero modbus de l'equipement dans la table equipements"""
	query = """UPDATE equipements 
	SET 
		num_mb = %d
	WHERE site='%s'
	AND groupe='%s'
	AND equipement='%s'
	""" % (
		num_mb,
		site,
		groupe,
		equipement,
	)
	system.db.runUpdateQuery(query,database)
	

def add_devio(database, site, groupe, equipement, id_devio, nom_devio):
	"""Ajout de l'id et nom devIO de l'equipement dans la table equipements"""
	query = """UPDATE equipements 
	SET 
		id_devio=%d,
		nom_devio='%s'
	WHERE site='%s'
	AND groupe='%s'
	AND equipement='%s'
	""" % (
		id_devio,
		nom_devio,
		site,
		groupe,
		equipement,
	)
	system.db.runUpdateQuery(query,database)
	

def update_tables(database, dataset, avec_modbus, avec_devio):
	"""Met a jour les tables equipements et plannings en fonction des donnees fournies"""
	for i in range(dataset.getRowCount()):
		site = dataset.getValueAt(i, "site")
		groupe = dataset.getValueAt(i, "groupe")
		equipement = dataset.getValueAt(i, "equipement")
		
		update_equipements(database, site, groupe, equipement)
		update_plannings(database, site, groupe, equipement)
		
		if avec_modbus:
			num_mb = dataset.getValueAt(i, "num_mb")
			if num_mb is not None: 
				add_num_mb(database, site, groupe, equipement, num_mb)
			
		if avec_devio:
			id_devio = dataset.getValueAt(i, "id_devio")
			nom_devio = dataset.getValueAt(i, "nom_devio")
			if id_devio is not None and nom_devio is not None:
				add_devio(database, site, groupe, equipement, id_devio, nom_devio)


def query_select_devices(device, site):
	"""Verifier la presence du device lié au site dans la table devices"""
	query = """
	Select * from devices
	where device = '%s'
	and site = '%s'
	""" % (
		device,
		site,
	)
	return query
		
		
def query_insert_devices(device, site):
	"""Ajout du device associé au site dans la table devices"""
	query = """
	Insert into devices
	(device, site)
	Values ('%s','%s')
	""" % (
		device,
		site,
	)
	return query


def update_devices(database, dataset):
	"""Ajout du device associé au site a la bdd s'il n'est pas deja present"""
	for i in range(dataset.getRowCount()):
		device = dataset.getValueAt(i, "device")
		site = dataset.getValueAt(i, "site")
		
		query = query_select_devices(device, site)		
		result = system.db.runQuery(query,database)
		if len(result)==0:
			query = query_insert_devices(device, site)
			system.db.runUpdateQuery(query,database)
