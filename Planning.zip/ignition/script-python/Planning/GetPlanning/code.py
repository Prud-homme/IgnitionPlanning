import system

def sql_to_date(strdate):
    """Renvoi un objet date a partir d'une date str YYYY-MM-DD"""
    year, month, day = [int(elt) for elt in str(strdate).split("-")]
    return system.date.getDate(year, month - 1, day)


def sous_liste_extend(liste):
    """Renvoie une liste qui ne contient plus de sous liste"""
    return [elt for sous_liste in liste for elt in sous_liste]


def test_exception(database, site, groupe, equipement, date):
    """Verifie si la date fourni correspond a une periode d'exception"""
    query = """
    select date_deb, date_fin from plannings_exception
    where site = '%s'
    and groupe = '%s'
    and equipement = '%s'
    and plage = 1
    """ % (
        site,
        groupe,
        equipement,
    )
    dataset = system.db.runQuery(query, database)
    en_exception = 0
    for date_deb, date_fin in dataset:
        target = date
        start = sql_to_date(date_deb)
        end = system.date.addMillis(system.date.addDays(sql_to_date(date_fin), 1), -1)
        if system.date.isBetween(target, start, end):
        	return True, date_deb, date_fin
    return False, None, None


def horaires_jour_plage_exception(
    database, site, groupe, equipement, jour, plage, date_deb, date_fin 
):
    """Renvoi les valeurs a ecrire d'une plage dans le cas d'un jour en exception"""
    if plage in [3, 4]:
        values = [0] * 4
        return values
    query = """
    select h_start, m_start, h_stop, m_stop from plannings_exception
    where site = '%s'
    and groupe = '%s'
    and equipement = '%s'
    and plage = %d
    and date_deb = '%s'
    and date_fin = '%s'
    """ % (
        site,
        groupe,
        equipement,
        plage,
        date_deb,
        date_fin,
    )
    #print query
    values = [
        str(time_value)
        for time_value in system.db.runQuery(query, database)[0]
    ]
    return values


def horaires_jour_plage(database, site, groupe, equipement, jour, plage):
    """Renvoi les valeurs a ecrire d'une plage dans le cas d'un jour en hebdo"""
    if plage in [3, 4]:
        values = [0] * 4
        return values
    query = """
    select h_start, m_start, h_stop, m_stop from plannings
    where site = '%s'
    and groupe = '%s'
    and equipement = '%s'
    and plage = %d
    and jour = %d
    """ % (
        site,
        groupe,
        equipement,
        plage,
        jour,
    )
    values = [
        str(time_value)
        for row in system.db.runQuery(query, database)
        for time_value in row
    ]
    return values


def horaires_jour(database, site, groupe, equipement, jour, en_exception):
    """Renvoi les valeurs a ecrire de toutes les plages d'un jour"""
    est_exception, date_deb, date_fin = en_exception
    values = []
    for plage in range(1, 5):
        if est_exception:
            values_plage = horaires_jour_plage_exception(
                database, site, groupe, equipement, jour, plage, date_deb, date_fin
            )
        else:
            values_plage = horaires_jour_plage(
                database, site, groupe, equipement, jour, plage
            )
        values.extend(values_plage)
    return values


def horaires_gp_eq(database, site, groupe, equipement):
    """Renvoi les valeurs a ecrire de tous les jours d'un equipement"""
    today = system.date.now()
    days = {
        1: 7,
        2: 1,
        3: 2,
        4: 3,
        5: 4,
        6: 5,
        7: 6,
    }
    values = [None] * 7
    for nb in range(7):
        date = system.date.addDays(today, nb)
        en_exception = test_exception(database, site, groupe, equipement, date)
        jour = days[system.date.getDayOfWeek(date)]
        #print 'estException', en_exception, jour
        values_jour = horaires_jour(
            database, site, groupe, equipement, jour, en_exception
        )
        values[jour - 1] = values_jour
    values = sous_liste_extend(values)
    values = [int(elt) for elt in values]
 
    return values
