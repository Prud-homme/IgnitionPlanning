import system

def liste_info_site_devio(database, site):
    """Renvoi une liste contenant chaque equipement du site avec son groupe, son id_devio et son nom_devio"""
    query = """
    select groupe, equipement, id_devio, nom_devio from equipements
    where site = '%s'
    and id_devio is not null
    and nom_devio is not null
    """ % (
        site
    )
    data = []
    for groupe, equipement, id_devio, nom_devio in system.db.runQuery(query, database):
        data.append([str(groupe), str(equipement), id_devio, nom_devio])
    return data

def horaires_site_devio(database, site, device, serverOPCUA):
	"""Decoupe en fonction d'un site"""
	data = liste_info_site_devio(database, site)
	for groupe, equipement, id_devio, nom_devio in data:
		values_gp_eq = Planning.GetPlanning.horaires_gp_eq(database, site, groupe, equipement)
		values_gp_eq = [str(elt).zfill(2) for elt in values_gp_eq]

def horaires_devio(database):
	"""Parcours de tous les sites"""
	sites = system.db.runQuery('Select distinct(site) from equipements', database)
	sites = [str(elt[0]) for elt in sites]
	for site in sites:
		horaires_site_devio(database, site)
