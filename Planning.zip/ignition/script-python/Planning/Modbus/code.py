import system

def liste_info_site_modbus(database, site):
    """Renvoi une liste contenant chaque equipement du site avec son groupe et num_mb"""
    query = """
    select groupe, equipement, num_mb from equipements
    where site = '%s'
    and num_mb is not null
    """ % (
        site
    )
    data = []
    for groupe, equipement, num_mb in system.db.runQuery(query, database):
        data.append([str(groupe), str(equipement), num_mb])
    return data


def dict_devices(database):
	"""
	Renvoi un dictionnaire où la clé est le nom du site dans la base de données
	et la valeur le nom du device
	"""
	query = "select nom_site, nom_device from devices"
	data = {}
	for nom_site, nom_device in system.db.runQuery(query, database):
		data[str(nom_site)] = str(nom_device)
	return data
	

def horaires_site_modbus(database, site, device, serverOPCUA):
    """Decoupe en fonction d'un site"""
    data = liste_info_site_modbus(database, site)
    for groupe, equipement, num_mb in data:
        depart = 25001 + (num_mb - 1) * 113
        adresses_gp_eq = range(depart, depart+113)
        adresses_gp_eq = ["[" + device + "]255.HR" + str(elt) for elt in adresses_gp_eq]
        
        values_gp_eq = Planning.GetPlanning.horaires_gp_eq(database, site, groupe, equipement)
        values_gp_eq.insert(0,0)
        
        returnQuality = system.opc.writeValues(serverOPCUA, adresses_gp_eq, values_gp_eq)
        #print returnQuality

def horaires_modbus(database, serverOPCUA):
    """Parcours de tous les sites"""
    devices = dict_devices(database)
    for site, device in devices.items():
        horaires_site_modbus(database, site, device, serverOPCUA)

"""
# Script à mettre dans la gateway
# Nom database Ignition
database = "MYSQL"

# Nom du serveur OPC UA
server = "Ignition OPC UA Server"

# Lancement du script
Planning.Modbus.horaires(database, serverOPCUA)
# --- Fin script ---
"""
