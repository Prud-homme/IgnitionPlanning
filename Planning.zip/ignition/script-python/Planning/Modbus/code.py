import system

def liste_info_site(database, site):
    """Renvoi une liste contenant chaque equipement du site avec son groupe et num_mb"""
    query = """
    select groupe, equipement, num_mb from equipements
    where site = '%s'
    and num_mb is not null
    """ % (
        site
    )
    data = []
    for groupe, equipement, num_mb in system.db.runQuery(query, database):
        data.append([str(groupe), str(equipement), num_mb])
    return data


def dict_devices(database):
	"""
	Renvoi un dictionnaire où la clé est le nom du site dans la base de données
	et la valeur le nom du device
	"""
	query = "select nom_site, nom_device from devices"
	data = {}
	for nom_site, nom_device in system.db.runQuery(query, database):
		data[str(nom_site)] = str(nom_device)
	return data
        

def adresse_sofrel(num_mb, jour, plage):
    """Renvoi l'adresse soffrel auquelle il faudra ajouter entre 1 et 4"""
    return 25001 + (num_mb - 1) * 113 + (jour - 1) * 16 + (plage - 1) * 4


def sql_to_date(strdate):
    """Renvoi un objet date a partir d'une date str YYYY-MM-DD"""
    year, month, day = [int(elt) for elt in str(strdate).split("-")]
    return system.date.getDate(year, month - 1, day)


def sous_liste_extend(liste):
    """Renvoie une liste qui ne contient plus de sous liste"""
    return [elt for sous_liste in liste for elt in sous_liste]


def test_exception(database, site, groupe, equipement, date):
    """Verifie si la date fourni correspond a une periode d'exception"""
    query = """
    select date_deb, date_fin from plannings_exception
    where site = '%s'
    and groupe = '%s'
    and equipement = '%s'
    and plage = 1
    """ % (
        site,
        groupe,
        equipement,
    )
    dataset = system.db.runQuery(query, database)
    en_exception = 0
    for date_deb, date_fin in dataset:
        target = date
        start = sql_to_date(date_deb)
        end = system.date.addMillis(system.date.addDays(sql_to_date(date_fin), 1), -1)
        if system.date.isBetween(target, start, end):
        	return True, date_deb, date_fin
    return False, None, None


def horaires_jour_plage_exception(
    database, site, groupe, equipement, num_mb, jour, plage, date_deb, date_fin 
):
    """Renvoi les adresses et valeurs a ecrire d'une plage dans le cas d'un jour en exception"""
    adresse = adresse_sofrel(num_mb, jour, plage)
    adresses = [adresse + 1, adresse + 2, adresse + 3, adresse + 4]
    if plage in [3, 4]:
        values = [0] * 4
        return adresses, values
    query = """
    select h_start, m_start, h_stop, m_stop from plannings_exception
    where site = '%s'
    and groupe = '%s'
    and equipement = '%s'
    and plage = %d
    and date_deb = '%s'
    and date_fin = '%s'
    """ % (
        site,
        groupe,
        equipement,
        plage,
        date_deb,
        date_fin,
    )
    #print query
    values = [
        str(time_value)
        for time_value in system.db.runQuery(query, database)[0]
    ]
    return adresses, values


def horaires_jour_plage(database, site, groupe, equipement, num_mb, jour, plage):
    """Renvoi les adresses et valeurs a ecrire d'une plage dans le cas d'un jour en hebdo"""
    adresse = adresse_sofrel(num_mb, jour, plage)
    adresses = [adresse + 1, adresse + 2, adresse + 3, adresse + 4]
    if plage in [3, 4]:
        values = [0] * 4
        return adresses, values
    query = """
    select h_start, m_start, h_stop, m_stop from plannings
    where site = '%s'
    and groupe = '%s'
    and equipement = '%s'
    and plage = %d
    and jour = %d
    """ % (
        site,
        groupe,
        equipement,
        plage,
        jour,
    )
    values = [
        str(time_value)
        for row in system.db.runQuery(query, database)
        for time_value in row
    ]
    return adresses, values


def horaires_jour(database, site, groupe, equipement, num_mb, jour, en_exception):
    """Renvoi les adresses et valeurs a ecrire de toutes les plages d'un jour"""
    est_exception, date_deb, date_fin = en_exception
    adresses = []
    values = []
    for plage in range(1, 5):
        if est_exception:
            adresses_plage, values_plage = horaires_jour_plage_exception(
                database, site, groupe, equipement, num_mb, jour, plage, date_deb, date_fin
            )
        else:
            adresses_plage, values_plage = horaires_jour_plage(
                database, site, groupe, equipement, num_mb, jour, plage
            )
        adresses.extend(adresses_plage)
        values.extend(values_plage)
    return adresses, values


def horaires_gp_eq(database, site, groupe, equipement, num_mb):
    """Renvoi les adresses et valeurs a ecrire de tous les jours d'un equipement"""
    today = system.date.now()
    days = {
        1: 7,
        2: 1,
        3: 2,
        4: 3,
        5: 4,
        6: 5,
        7: 6,
    }
    adresses = [None] * 7
    values = [None] * 7
    for nb in range(7):
        date = system.date.addDays(today, nb)
        en_exception = test_exception(database, site, groupe, equipement, date)
        jour = days[system.date.getDayOfWeek(date)]
        #print 'estException', en_exception, jour
        adresses_jour, values_jour = horaires_jour(
            database, site, groupe, equipement, num_mb, jour, en_exception
        )
        adresses[jour - 1] = adresses_jour
        values[jour - 1] = values_jour
    adresses = sous_liste_extend(adresses)
    values = sous_liste_extend(values)
    
    adresses.insert(0, adresses[0]-1)
    values.insert(0,0)
    
    return adresses, values


def horaires_site(database, site, device, serverOPCUA):
    """Decoupe en fonction d'un site"""
    data = liste_info_site(database, site)
    for groupe, equipement, num_mb in data:
        adresses_gp_eq, values_gp_eq = horaires_gp_eq(
            database, site, groupe, equipement, num_mb
        )
        adresses_gp_eq = ["[" + device + "]255.HR" + str(elt) for elt in adresses_gp_eq]
        values_gp_eq = [int(elt) for elt in values_gp_eq]
        
        returnQuality = system.opc.writeValues(serverOPCUA, adresses_gp_eq, values_gp_eq)
        #print returnQuality

def horaires(database, serverOPCUA):
    """Parcours de tous les sites"""
    devices = dict_devices(database)
    for site, device in devices.items():
        horaires_site(database, site, device, serverOPCUA)

"""
# Script à mettre dans la gateway
# Nom database Ignition
database = "MYSQL"

# Nom du serveur OPC UA
server = "Ignition OPC UA Server"

# Lancement du script
PlanningModbus.horaires(database, serverOPCUA)
# --- Fin script ---
"""
